﻿# Mystanic Datapack
Made by **JacktheGEAT**

co-editors:

    Puff

    DumByAWaffle

    VeSaucy

    idk they helped a ton at the start but im doing this solo now.

Make sure you download the resource pack here:
  > add resource pack here when you can

just a quick disclaimer: this project is a WORK IN PROGRESS

MAJOR bugs, does absolutely NOTHING to base game yet, and half the stuff doesn't work.

also it could have spyware and viruses or something idk. its not like i made it or anything.

that was a joke i made it it shouldnt break your computer or anything. probably.

How to summon bee keeper: 

    go to flower forest
    
    break bee nests until warning appears
    
    break bee nests with 20% chance of beekeeper spawning
    
added give commands: /function mystanic:give/(insert item here)

# Known Bugs:
  > Sword of Avarice buggs out at 214748 kills. if someone manages to get that many kills in a survival world, without commands or hacks, i will give you 100$. until then, thats just too big a number for me to care.
